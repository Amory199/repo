# -*- coding: utf-8 -*-

from odoo import fields, models, api


class StockPicking(models.Model):
    _inherit = "stock.picking"

class StockMove(models.Model):
    _inherit = "stock.move"

    # cost = fields.Float(
    #     string='Cost',
    #     compute='_compute_cost',
    # )
    total_cost = fields.Float(
        string='Total Cost',
        compute='_compute_total_cost'
    )   

    # def _compute_cost(self):
    #     for move in self:
    #         move.cost = move.product_id.standard_price if move.product_id else 0.0
            
    cost = fields.Float(
        string='Cost',
        compute='_compute_fifo_cost',
        store=True,
    )

    @api.depends('product_id', 'state')
    def _compute_fifo_cost(self):
        for move in self:
            if not move.product_id:
                move.cost = 0.0
                continue

            # Find the first valuation layer (FIFO) with remaining_qty > 0
        fifo_layers = self.env['stock.valuation.layer'].search([
            ('product_id', '=', move.product_id.id),
            ('remaining_qty', '>', 0),
        ], order='create_date asc')

        qty_needed = move.product_uom_qty
        cost_total = 0.0
        qty_taken = 0.0

        for layer in fifo_layers:
            take_qty = min(layer.remaining_qty, qty_needed)
            cost_total += take_qty * abs(layer.remaining_value / layer.remaining_qty)
            qty_taken += take_qty
            qty_needed -= take_qty
            if qty_needed <= 0:
                break

        move.cost = cost_total / qty_taken if qty_taken else 0.0

    def _compute_total_cost(self):
        for move in self:
            move.total_cost = move.cost * move.product_uom_qty